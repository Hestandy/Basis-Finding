#include "basisFind.h"

VB	CN_err;//1: CN is incorrect; 0: CN is correct
int	times_n_cor_basis = 0;
LL	num_inc_basis = 0;
double	basis_wt = 0.0;
VD	p_att_mean(2, 0.0);
VD	p_att_var(2, 0.0);

//input: m, n, l, CN_adj, CN_val, num_inact, CN_pos_idx, VN_idx_pos
//return 0: n correct basis elements and they uniquely attend top n linear representations; 
//1: error: less than n correct basis elements;
//2: error: n correct basis elements but they do not uniquely attend top n linear representations
int BFA_straightforward(){				
	VI	num_basis(2, 0);//0/1: number of correct/incorrect basis elements
	VI	num_LR;//#LR (linear representation) each basis element attends
	VB	basis_err;
	VVI	B(n + l), Q(n + l);
	int	sum_wt = 0;
	
	for (int i = 0; ; ++ i){
		if (num_basis[1] > l || num_basis[0] + m - i < n){
			return	1;//error due to correct basis is not full rank
		}
		else if (i == m){
			break;
		}
		
		int min_v = -1;
		VI b = CN_val[CN_pos_idx[i]];
		b.resize((l+num_inact+BWI-1)/BWI, 0);
		VI q((num_LR.size() + BWI-1)/BWI, 0);
		for (int j = 0; j < CN_adj[CN_pos_idx[i]].size(); ++ j){
			assert(CN_adj[CN_pos_idx[i]][j] >= 0 && CN_adj[CN_pos_idx[i]][j] < n);
			int v = VN_idx_pos[CN_adj[CN_pos_idx[i]][j]];
			if (v + num_inact < n){//v belongs to L
				if (B[v].empty()){
					assert(min_v == -1);
					min_v = v;
				}
				else{
					xorEq(b, B[v]);
					xorEq(q, Q[v]);//q may be longer than Q[v] 
				}
			}
			else{
				b[(n+l-1-v)/BWI] ^= (1 << (n+l-1-v)%BWI);
			}
		}
		
		for (int j = b.size() - 1; j >= 0 && min_v == -1; -- j){
			for (int t = BWI-1; t >= 0 && b[j] != 0; -- t){
				if (b[j] & (1 << t)){
					int cur_v = n+l-1-j*BWI-t;
					assert(cur_v + num_inact >= n);//cur_v belongs to R
					if (B[cur_v].empty()){
						min_v = cur_v;
						break;
					}
					else{
						xorEq(b, B[cur_v]);
						xorEq(q, Q[cur_v]);
					}
				}
			}
		}
		
		if (min_v != -1){//add into basis
			B[min_v] = b;
			Q[min_v] = q;
			if (num_LR.size()%BWI == 0){
				Q[min_v].push_back(0);
			}
			Q[min_v].back() ^= (1 << num_LR.size()%BWI);
			num_LR.push_back(0);
			basis_err.push_back(CN_err[CN_pos_idx[i]]);
			++ num_basis[basis_err.back()];
			sum_wt += CN_adj[CN_pos_idx[i]].size();
		}
		else{//b is a LC of the current basis; q indicates the basis elements
			for (int t = 0; t < q.size(); ++ t){
				if (q[t] != 0){
					for (int j = 0; j < BWI; ++ j){
						if ((q[t] >> j) & 1){
							++ num_LR[t * BWI + j];
						}
					}
				}
			}
		}
	}
	
	assert(num_basis[0] == n && num_basis[1] <= l);
	++ times_n_cor_basis;
	num_inc_basis += num_basis[1];
	basis_wt += 1.0 * sum_wt / (num_basis[0] + num_basis[1]);
	
	int cor_min = m;//minimum LRs of correct basis
	int err_max = -1;//maximum LRs of erroneous basis
	VLL	sum_LR(2, 0);
	VLL	sum2_LR(2, 0);
	for (int i = 0; i < num_LR.size(); ++ i){
		if (basis_err[i]){
			err_max = max (err_max, num_LR[i]);
		}
		else{
			cor_min = min (cor_min, num_LR[i]);
		}
		sum_LR[basis_err[i]] += num_LR[i];
		sum2_LR[basis_err[i]] += 1LL * num_LR[i] * num_LR[i];
	}
	
	double redunSym = max(1, m - num_basis[0] - num_basis[1]);
	for (int i = 0; i < 2; ++ i){
		double ave = sum_LR[i] / redunSym / max(num_basis[i], 1);
		p_att_mean[i] += ave;
		p_att_var[i] += sum2_LR[i] / redunSym / redunSym / max(num_basis[i], 1) - ave * ave;
	}
	
	return	cor_min > err_max ? 0 : 2;
}

bool cmp(int CN_idx1, int CN_idx2){
	return	CN_adj[CN_idx1].size() > CN_adj[CN_idx2].size();
}

//input: m, n, l, CN_adj, CN_val
//return 0: n correct basis elements and they uniquely attend top n linear representations; 
//1: error: less than n correct basis elements;
//2: error: n correct basis elements but they do not uniquely attend top n linear representations
int	BFA(){
	assert(m == CN_adj.size() && m == CN_val.size() && n > 0 && (l+BWI-1)/BWI == CN_val[0].size());
	if (dec_type == "eff"){//efficient BFA
		//get form [L R], where L is a lower triangular matrix; |R| = num_inact
		if (!triangulation()){
			return	1;//error due to existing zero columns
		}
	}
	else{
		num_inact = n;//indicate L is empty and R is full
		CN_pos_idx.resize(m);
		for (int i = 0; i < m; ++ i){
			CN_pos_idx[i] = i;
		}
		if (dec_type == "sort"){
			sort(CN_pos_idx.begin(), CN_pos_idx.end(), cmp);//sort received symbols from most weighted to least weighted
		}
		VN_idx_pos.resize(n);
		for (int i = 0; i < VN_idx_pos.size(); ++ i){
			VN_idx_pos[i] = i;
		}
	}
	return	BFA_straightforward();
}

