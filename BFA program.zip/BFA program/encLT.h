#ifndef __encLT_h__
#define __encLT_h__

#include "globalFile.h"

//global parameters generated and shared by encLT
extern double RSD_delta;
extern double RSD_c;
extern VD distri_LT;//cumulative weight distribution for encoding symbols

VD creat_ISD(int size);

VD creat_RSD(int size);

void LT_encode(const VVI &info, VVI &CN_adj, VVI &CN_val);

#endif
