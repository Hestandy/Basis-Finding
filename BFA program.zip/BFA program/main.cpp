#include "globalFile.h"
#include "myIO.h"
#include "triangulation.h"
#include "encLT.h"
#include "basisFind.h"
#include "BP4LT.h"
#include "statistics.h"

const int MAX_FE = 10;//maximum frame errors to stop decoding 
const int MIN_TC = 100;//minimum testcases to stop decoding
const int MAX_TC = 100;//minimum testcases to stop decoding

int	m;//#CNs
int	n;//#VNs
int	l;//bit-width of CN value
VVI	CN_adj;//neighbors of CNs
VVI VN_adj;//neighbors of VNs
VVI	CN_val;//XOR value of CNs
string dec_type;//BP, eff, str <-> BP, efficient BFA, straightforward BFA

void test_LT(const string &logFile, const double &p, const double &overhead, unsigned seed){
	cerr << "seed " << seed << endl;
	cerr << "p " << p << "; overhead " << overhead << endl;
	
	assert(dec_type == "BP" || dec_type == "eff" || dec_type == "str" || dec_type == "sort");
	
	CN_adj.resize(m);
	CN_val.resize(m);
	CN_err.resize(m);
	times_n_cor_basis = 0;
	num_inc_basis = 0;
	basis_wt = 0.0;
	p_att_mean.clear();
	p_att_mean.resize(2, 0.0);
	p_att_var = p_att_mean;

	clock_t start = clock();
	clock_t	testSec = 0;
	clock_t	triangSec = 0;
	int testCases = 0;
	int wordErr = 0;
	int wordErr_rank = 0;//error due to correct bases is not full rank
	VD inact_pow(3, 0);
	while((wordErr < MAX_FE || testCases < MIN_TC) && testCases < MAX_TC){
		++ testCases;
		
		//generate info
		VVI info = rand_VVI(n, (l + BWI - 1) / BWI);
		if (l % BWI != 0){
			int mask = (1 << l % BWI) - 1;
			for (int i = 0; i < info.size(); ++ i){
				info[i].back() &= mask;//make the tail bits be 0
			}
		}
		//generate received CNs
		LT_encode(info, CN_adj, CN_val);
		
		//inject errors
		int cnt_err = 0;
		for (int i = 0; i < CN_val.size(); ++ i){
			CN_err[i] = randu() >= p;
			if (CN_err[i]){
				++ cnt_err;
				while (true){
					VI errors = rand_VI(CN_val[i].size());
					if (l % BWI != 0){
						errors.back() &= (1 << l % BWI) - 1;
					}
					if (!be_zeros(errors)){
						xorEq(CN_val[i], errors);
						break;
					}
				}
			}
		}
		
		clock_t startDec = clock();
		
		if (dec_type == "BP"){//for BP
			wordErr += !BP(p, info);
			wordErr_rank = wordErr;
		}
		else{//for BFA
			if (cnt_err + n > m){
				++ wordErr;
				++ wordErr_rank;
			}
			else{
				int res = BFA();
				if (res == 1){
					++ wordErr;
					++ wordErr_rank;
				}
				else if (res == 2){
					++ wordErr;
				}
				else{
					assert(res == 0);
				}
			}
		}
		
		testSec += clock() - startDec;//excluding encoding time
		triangSec += time_triang;
		
		for (int t = 0; t < inact_pow.size(); ++ t){
			inact_pow[t] += pow(num_inact, t + 1);
		}
		
		if (clock() > start + 10 * CLOCKS_PER_SEC || testCases == MIN_TC \
		|| testCases == MAX_TC || wordErr_rank == MAX_FE || wordErr == MAX_FE){
			start = clock();
			
			FILE *fp = fopen (logFile.c_str(), "w");
			fprintf(fp, "seed              %u\n\n", seed);
			
			fprintf(fp, "dec_type          %s\n", dec_type.c_str());
			fprintf(fp, "use_DSDS          %d\n\n", use_DSDS);
			
			fprintf(fp, "code              LT\n");
			fprintf(fp, "RSD_delta         %f\n", RSD_delta);
			fprintf(fp, "RSD_c             %f\n\n", RSD_c);
			
			fprintf(fp, "l                 %d\n", l);
			fprintf(fp, "n                 %d\n\n", n);
			
			fprintf(fp, "p                 %.2f\n", p);
			fprintf(fp, "overhead          %f\n", overhead);
			fprintf(fp, "m                 %d\n\n", m);
			
			fprintf(fp, "testCases         %d\n", testCases);
			fprintf(fp, "wordErr           %d\n", wordErr);
			fprintf(fp, "FER               %f\n", 1.0 * wordErr / testCases);
			fprintf(fp, "wordErr_rank      %d\n", wordErr_rank);
			fprintf(fp, "FER_rank          %f\n\n", 1.0 * wordErr_rank / testCases);
			
			double tmp = max(1, times_n_cor_basis);
			fprintf(fp, "times_n_cor_basis %d\n", times_n_cor_basis);
			fprintf(fp, "num_inc_basis     %f\n", num_inc_basis / tmp);
			fprintf(fp, "basis_wt          %f\n", basis_wt / tmp);
			fprintf(fp, "p_att_mean        %f    \t%f\n", p_att_mean[0] / tmp, p_att_mean[1] / tmp);
			fprintf(fp, "p_att_var         %f    \t%f\n\n", p_att_var[0] / tmp, p_att_var[1] / tmp);
			
			fprintf(fp, "testSec           %f\n", 1.0 * testSec / CLOCKS_PER_SEC);
			fprintf(fp, "perTestSec        %f\n", 1.0 * testSec / CLOCKS_PER_SEC / testCases);
			fprintf(fp, "triangSec         %f\n", 1.0 * triangSec / CLOCKS_PER_SEC);
			fprintf(fp, "perTriangSec      %f\n", 1.0 * triangSec / CLOCKS_PER_SEC / testCases);
			fprintf(fp, "inact_pow         %d\n", inact_pow.size());
			for (int t = 0; t < inact_pow.size(); ++ t){
				fprintf(fp, "%d    %f    %f\n", t+1, inact_pow[t], inact_pow[t] / testCases);
			} 
			
			fprintf(fp, "\ncomplete_testSec  %f\n", 1.0 * testSec / CLOCKS_PER_SEC * \
			min(MAX_FE / (wordErr + 1e-6), 1.0 * MAX_TC / testCases));
			fclose (fp);
			
//			makeCopy (logFile.c_str());
		}
	}
}



void set_distri_LT(){
	
	RSD_delta = 0.01;
	RSD_c = 0.02;
	distri_LT = creat_RSD(n);
	
//	distri_LT.clear();//ETESAMI AND SHOKROLLAHI 2006
//	distri_LT.resize(201, 0);
//	distri_LT[1] = 0.006;
//	distri_LT[2] = 0.492;
//	distri_LT[3] = 0.0339;
//	distri_LT[4] = 0.2403;
//	distri_LT[5] = 0.006;
//	distri_LT[8] = 0.095;
//	distri_LT[14] = 0.049;
//	distri_LT[30] = 0.018;
//	distri_LT[33] = 0.0356;
//	distri_LT[200] = 0.033;
	
//	distri_LT.clear();//ETESAMI AND SHOKROLLAHI 2006 (14)
//	distri_LT.resize(67, 0);
//	distri_LT[1] = 0.008;
//	distri_LT[2] = 0.494;
//	distri_LT[3] = 0.166;
//	distri_LT[4] = 0.073;
//	distri_LT[5] = 0.083;
//	distri_LT[8] = 0.056;
//	distri_LT[9] = 0.037;
//	distri_LT[19] = 0.056;
//	distri_LT[65] = 0.025;
//	distri_LT[66] = 0.003;
	
	for (int i = 2; i < distri_LT.size(); ++ i){
		distri_LT[i] += distri_LT[i - 1];
	}
	distri_LT[0] = 0;
	double ave_wt = 0.0;
	for (int i = 1; i < distri_LT.size(); ++ i){
		distri_LT[i] /= distri_LT.back();
		ave_wt += (distri_LT[i] - distri_LT[i-1]) * i;
	}
	distri_LT[0] = -1;//never select 0
	distri_LT.back() += eps;//ensure distri_LT.back() > 1
	cerr << "average weight of distri_LT: " << ave_wt << endl;
}

int main(){
	//A * X = Y, A, X, Y are of dimensions m * n, n * l, m * l.
	//p is the probability for each Ai * X = Yi
	
	dec_type = "BP";//BP, eff, str, sort <-> BP, efficient BFA, straightforward BFA, sorted BFA
	maxIter = 100;//only valid for BP
		
	l = 100;//bit-width of CN value
	n = 1000;//#VNs
	
	set_distri_LT();
	
	VS		dirNames;
	double	p[] = {0.55, 0.6, 0.65, 0.7, 1};//correct probability for encoded symbols
//	double	p[] = {0.94, 0.96, 0.98, 1};//correct probability for encoded symbols
	double	overhead[] = {10 << 0, 10 << 1, 10 << 2, 10 << 3, 10 << 4, 10 << 5, 10 << 6, 10 << 7, 10 << 8};//m = (n + overhead) / p
//	
//	//test FER
	for (int j = 0; j <= 0; ++ j){//overhead
		for (int i = 0; i <= 3; ++ i){//p
			char dirName[100] = "";
			sprintf(dirName, "%s,l=%d,n=%d,p=%.2f", dec_type.c_str(), l, n, p[i]);
			dirNames.push_back(dirName);
			
			string logFile;
			_mkdir(dirName);
			logFile = creatNewFile ((dirNames.back() + "\\log").c_str());
			unsigned seed = getFileNum(logFile.c_str()) + (time(NULL) << 10);
			PRNG.seed(seed);

			m = (n + overhead[j]) / p[i];
			test_LT(logFile, p[i], overhead[j], seed);
		}
	}
	
	//compute FER, etc. (better to comment above test)
//	char dirName[][100] = {
//		"BP",
//		"eff",
//		"str",
//		"sort",
//	};
//	for (int t = 0; t < 4; ++ t){
//		for (int i = 0; i <= 3; ++ i){//p
//			sprintf(data_buff, "%s,l=%d,n=%d,p=%.2f", dirName[t], l, n, p[i]);
//			dirNames.push_back(data_buff);
//		}
//	}
//	statistics("data_summary.txt", dirNames, 600);
	
	return	0;
}


