#include "encLT.h"

double RSD_delta = -1;//default ISD
double RSD_c = -1;

VD distri_LT; 

VD creat_ISD(int size){
	assert(size > 0);
	
	VD	ISD(size + 1);
	ISD[1] = 1.0 / size;
	for (int i = 2; i <= size; ++ i){
		ISD[i] = 1.0 / i / (i - 1);
	}
	return	ISD;
}

VD creat_RSD(int size){
	assert(size > 0);
	
	cerr << "RSD_delta: " << RSD_delta << "; RSD_c: " << RSD_c << endl;
	
	VD rou = creat_ISD(size);
	VD tau(size + 1, 0.0);
	double s = RSD_c * log(size / RSD_delta) * sqrt(size);
//	cerr << "RSD s: " << s << endl;
	int max_num = size / s + 0.5;
	if (max_num > size){
		max_num = size;
	} 
	tau[max_num] = s / size * log(s / RSD_delta);
	cerr << "RSD max_num: " << max_num << endl;
	for (int i = 1; i < max_num; ++ i){
		tau[i] = s / size / i;
	}
	
	VD RSD(size + 1);
	double sum = 0;
	for (int i = 1; i <= size; ++ i){
		RSD[i] = rou[i] + tau[i];
		sum += RSD[i];
	}
//	cerr << "RSD Z: " << RSD[size] << endl;
	for (int i = 1; i <= size; ++ i){
		RSD[i] /= sum;
	}
	return	RSD;
}

int rand_weight(){
//	binomial_distribution<int> bd(distri_LT.size() - 1, 0.5);
//	return	bd(PRNG);
	
	double	pu = randu();
	for (int i = 1; i < distri_LT.size(); ++ i){//as the sum of weights is small, this is faster than binary search
		if (pu <= distri_LT[i]){
			return	i;
		}
	}
}

void LT_encode(const VVI &info, VVI &CN_adj, VVI &CN_val){
	assert(CN_adj.size() == CN_val.size());
	
	for (int i = 0; i < CN_adj.size(); ++ i){
		CN_adj[i] = a_choose_b(info.size(), rand_weight());
		CN_val[i] = info[CN_adj[i][0]];
		for (int j = 1; j < CN_adj[i].size(); ++ j){
			xorEq(CN_val[i], info[CN_adj[i][j]]);
		}
	}
}

