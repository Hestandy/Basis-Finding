#include "statistics.h"
 
int L1 = 20;
const int L2 = 10;

map <double, int>	keys;//different overhead
VLL	testCases;
VLL	wordErr;
VLL	wordErr_rank;
VLL	times_n_cor_basis_;
VD	num_inc_basis_;
VD	basis_wt_;
VVD	p_att_mean_;
VVD	p_att_var_;
VD	testSec;
VD	triangSec;
VVD	inact_pow;

void init (const char *fileName){
	FILE *fp = fopen (fileName, "r");
	if (fp == NULL)	return;
	while (fscanf (fp, "%s", data_buff) != EOF){
		if ((string)"overhead" == data_buff){
			double tmp;
			fscanf (fp, "%lf", &tmp);	
			if (keys.find(tmp) == keys.end()){
				keys[tmp] = 0;
			}
			break;
		}
	}
	fclose (fp);
}

void calc (const char *fileName){
	FILE *fp = fopen (fileName, "r");
	if (fp == NULL)	return;
	int idx = -1;
	double tmpD;
	LL	tmpLL;
	int cur_times_n_cor_basis;
	while (fscanf (fp, "%s", data_buff) != EOF){
		if ((string)"overhead" == data_buff){			
			fscanf (fp, "%lf", &tmpD);
			idx = keys[tmpD];
		}
		else if ((string)"testCases" == data_buff){
			fscanf (fp, "%lld", &tmpLL);
			testCases[idx] += tmpLL;
		}
		else if ((string)"wordErr" == data_buff){
			fscanf (fp, "%lld", &tmpLL);
			wordErr[idx] += tmpLL;
		}
		else if ((string)"wordErr_rank" == data_buff){
			fscanf (fp, "%lld", &tmpLL);
			wordErr_rank[idx] += tmpLL;
		}
		else if ((string)"times_n_cor_basis" == data_buff){
			fscanf (fp, "%d", &cur_times_n_cor_basis);
			times_n_cor_basis_[idx] += cur_times_n_cor_basis;
		}
		else if ((string)"num_inc_basis" == data_buff){
			fscanf (fp, "%lf", &tmpD);
			num_inc_basis_[idx] += tmpD * cur_times_n_cor_basis;
		}
		else if ((string)"basis_wt" == data_buff){
			fscanf (fp, "%lf", &tmpD);
			basis_wt_[idx] += tmpD * cur_times_n_cor_basis;
		}
		else if ((string)"p_att_mean" == data_buff){
			for (int i = 0; i < p_att_mean_.size(); ++ i){
				fscanf (fp, "%lf", &tmpD);
				p_att_mean_[i][idx] += tmpD * cur_times_n_cor_basis;
			}
		}
		else if ((string)"p_att_var" == data_buff){
			for (int i = 0; i < p_att_var_.size(); ++ i){
				fscanf (fp, "%lf", &tmpD);
				p_att_var_[i][idx] += tmpD * cur_times_n_cor_basis;
			}
		}
		else if ((string)"testSec" == data_buff){
			fscanf (fp, "%lf", &tmpD);
			testSec[idx] += tmpD;
		}
		else if ((string)"triangSec" == data_buff){
			fscanf (fp, "%lf", &tmpD);
			triangSec[idx] += tmpD;
		}
		else if ((string)"inact_pow" == data_buff){
			fscanf (fp, "%lld", &tmpLL);
			assert(tmpLL == inact_pow.size());
			for (int i = 0; i < inact_pow.size(); ++ i){
				fscanf (fp, "%lld", &tmpLL);
				fscanf (fp, "%lf", &tmpD);
				inact_pow[i][idx] += tmpD;
				fscanf (fp, "%lf", &tmpD);
			}
		}
	}
	fclose (fp);
}

void statistics(const char *outFile, const VS &dirName, int num_log){
	freopen (outFile, "w", stdout);
	
	char fileName[100];
	for (int i = 0; i < dirName.size(); ++ i){
		if (dirName[i].size() > L1){
			L1 = dirName[i].size();
		}
		for (int num = 1; num <= num_log; ++ num){
			if (dirName[i].empty()){
				sprintf (fileName, "log (%d).txt", num);
			}
			else{
				sprintf (fileName, "%s\\log (%d).txt", dirName[i].c_str(), num);
			}
			init (fileName);
		}
	}
	
	outputLength("overhead", L1);
	for (map <double, int> :: iterator it = keys.begin(); it != keys.end(); ++ it){
		sprintf(data_buff, "%f", it->first);
		outputLength(data_buff, L2);
		it->second = testCases.size();
		testCases.push_back(0);
	}
	puts("");
	wordErr.resize(testCases.size(), 0);
	wordErr_rank.resize(testCases.size(), 0);
	times_n_cor_basis_.resize(testCases.size(), 0);
	num_inc_basis_.resize(testCases.size(), 0);
	basis_wt_.resize(testCases.size(), 0);
	p_att_mean_.resize(2, VD(testCases.size(), 0.0));
	p_att_var_ = p_att_mean_;
	testSec.resize(testCases.size(), 0.0);
	triangSec.resize(testCases.size(), 0.0);
	inact_pow.resize(3, VD(testCases.size(), 0.0));
	
	
	vector <VLL>	v_testCases;
	vector <VLL>	v_wordErr;
	vector <VLL>	v_wordErr_rank;
	vector <VLL>	v_times_n_cor_basis_;
	vector <VD>		v_num_inc_basis_;
	vector <VD>		v_basis_wt_;
	vector <VVD>	v_p_att_mean_;
	vector <VVD>	v_p_att_var_;
	vector <VD>		v_testSec;
	vector <VD>		v_triangSec;
	vector <VVD>	v_inact_pow;
	for (int i = 0; i < dirName.size(); ++ i){
		fill(testCases.begin(), testCases.end(), 0);
		fill(wordErr.begin(), wordErr.end(), 0);
		fill(wordErr_rank.begin(), wordErr_rank.end(), 0);
		fill(times_n_cor_basis_.begin(), times_n_cor_basis_.end(), 0);
		fill(num_inc_basis_.begin(), num_inc_basis_.end(), 0.0);
		fill(basis_wt_.begin(), basis_wt_.end(), 0.0);
		for (int j = 0; j < p_att_mean_.size(); ++ j){
			fill(p_att_mean_[j].begin(), p_att_mean_[j].end(), 0.0);
			fill(p_att_var_[j].begin(), p_att_var_[j].end(), 0.0);
		}
		fill(testSec.begin(), testSec.end(), 0.0);
		fill(triangSec.begin(), triangSec.end(), 0.0);
		for (int j = 0; j < inact_pow.size(); ++ j){
			fill(inact_pow[j].begin(), inact_pow[j].end(), 0);
		}
		
		for (int num = 1; num <= num_log; ++ num){
			if (dirName[i].empty()){
				sprintf (fileName, "log (%d).txt", num);
			}
			else{
				sprintf (fileName, "%s\\log (%d).txt", dirName[i].c_str(), num);
			}
			calc (fileName);
		}
		
		v_testCases.push_back(testCases);
		v_wordErr.push_back(wordErr);
		v_wordErr_rank.push_back(wordErr_rank);
		v_times_n_cor_basis_.push_back(times_n_cor_basis_);
		v_num_inc_basis_.push_back(num_inc_basis_);
		v_basis_wt_.push_back(basis_wt_);
		v_p_att_mean_.push_back(p_att_mean_);
		v_p_att_var_.push_back(p_att_var_);
		v_testSec.push_back(testSec);
		v_triangSec.push_back(triangSec);
		v_inact_pow.push_back(inact_pow);
	}
	
	puts("\ntestCases");
	for (int i = 0; i < dirName.size(); ++ i){
		outputLength(dirName[i], L1);
		for (int j = 0; j < v_testCases[i].size(); ++ j){
			sprintf(data_buff, "%lld", v_testCases[i][j]);
			outputLength(data_buff, L2);
		}
		puts(";");
	}
	
	puts("\nwordErr");
	for (int i = 0; i < dirName.size(); ++ i){
		outputLength(dirName[i], L1);
		for (int j = 0; j < v_testCases[i].size(); ++ j){
			sprintf(data_buff, "%lld", v_wordErr[i][j]);
			outputLength(data_buff, L2);
		}
		puts(";");
	}
	
	puts("\nFER");
	for (int i = 0; i < dirName.size(); ++ i){
		outputLength(dirName[i], L1);
		for (int j = 0; j < v_testCases[i].size(); ++ j){
			sprintf(data_buff, "%.4e", 1.0 * v_wordErr[i][j] / v_testCases[i][j]);
			outputLength(data_buff, L2);
		}
		puts(";");
	}
	
	puts("\nwordErr_rank");
	for (int i = 0; i < dirName.size(); ++ i){
		outputLength(dirName[i], L1);
		for (int j = 0; j < v_testCases[i].size(); ++ j){
			sprintf(data_buff, "%lld", v_wordErr_rank[i][j]);
			outputLength(data_buff, L2);
		}
		puts(";");
	}
	
	puts("\nFER_rank");
	for (int i = 0; i < dirName.size(); ++ i){
		outputLength(dirName[i], L1);
		for (int j = 0; j < v_testCases[i].size(); ++ j){
			sprintf(data_buff, "%.4e", 1.0 * v_wordErr_rank[i][j] / v_testCases[i][j]);
			outputLength(data_buff, L2);
		}
		puts(";");
	}
	
	puts("\ntimes_n_cor_basis");
	for (int i = 0; i < dirName.size(); ++ i){
		outputLength(dirName[i], L1);
		for (int j = 0; j < v_testCases[i].size(); ++ j){
			sprintf(data_buff, "%lld", v_times_n_cor_basis_[i][j]);
			outputLength(data_buff, L2);
		}
		puts(";");
	}
	
	puts("\nnum_inc_basis");
	for (int i = 0; i < dirName.size(); ++ i){
		outputLength(dirName[i], L1);
		for (int j = 0; j < v_testCases[i].size(); ++ j){
			sprintf(data_buff, "%.1f", v_num_inc_basis_[i][j] / max(1LL, v_times_n_cor_basis_[i][j]));
			outputLength(data_buff, L2);
		}
		puts(";");
	}
	
	puts("\nbasis_wt");
	for (int i = 0; i < dirName.size(); ++ i){
		outputLength(dirName[i], L1);
		for (int j = 0; j < v_testCases[i].size(); ++ j){
			sprintf(data_buff, "%.1f", v_basis_wt_[i][j] / max(1LL, v_times_n_cor_basis_[i][j]));
			outputLength(data_buff, L2);
		}
		puts(";");
	}
	
	for (int t = 0; t < p_att_mean_.size(); ++ t){
		printf("\np_att_mean  %s\n", t ? "incorrect" : "correct");
		for (int i = 0; i < dirName.size(); ++ i){
			outputLength(dirName[i], L1);
			for (int j = 0; j < v_testCases[i].size(); ++ j){
				sprintf(data_buff, "%f", v_p_att_mean_[i][t][j] / max(1LL, v_times_n_cor_basis_[i][j]));
				outputLength(data_buff, L2);
			}
			puts(";");
		}
	}
	
	for (int t = 0; t < p_att_var_.size(); ++ t){
		printf("\np_att_var  %s\n", t ? "incorrect" : "correct");
		for (int i = 0; i < dirName.size(); ++ i){
			outputLength(dirName[i], L1);
			for (int j = 0; j < v_testCases[i].size(); ++ j){
				sprintf(data_buff, "%f", v_p_att_var_[i][t][j] / max(1LL, v_times_n_cor_basis_[i][j]));
				outputLength(data_buff, L2);
			}
			puts(";");
		}
	}
	
	puts("\ntestSec");
	for (int i = 0; i < dirName.size(); ++ i){
		outputLength(dirName[i], L1);
		for (int j = 0; j < v_testCases[i].size(); ++ j){
			sprintf(data_buff, "%f", 1.0 * v_testSec[i][j] / v_testCases[i][j]);
			outputLength(data_buff, L2);
		}
		puts(";");
	}
	
	puts("\ntriangSec");
	for (int i = 0; i < dirName.size(); ++ i){
		outputLength(dirName[i], L1);
		for (int j = 0; j < v_testCases[i].size(); ++ j){
			sprintf(data_buff, "%f", 1.0 * v_triangSec[i][j] / v_testCases[i][j]);
			outputLength(data_buff, L2);
		}
		puts(";");
	}
	
	for (int t = 0; t < inact_pow.size(); ++ t){
		printf("\ninact_pow  %d\n", t + 1);
		for (int i = 0; i < dirName.size(); ++ i){
			outputLength(dirName[i], L1);
			for (int j = 0; j < v_testCases[i].size(); ++ j){
				sprintf(data_buff, "%f", 1.0 * v_inact_pow[i][t][j] / v_testCases[i][j]);
				outputLength(data_buff, L2);
			}
			puts(";");
		}
	}
}

