#ifndef __statistics_h__
#define __statistics_h__

#include "globalFile.h"
#include "myIO.h"

void statistics(const char *outFile, const VS &dirName, int num_log);

#endif
