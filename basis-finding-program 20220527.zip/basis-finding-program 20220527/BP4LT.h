#ifndef __BP4LT_h__
#define __BP4LT_h__

#include "globalFile.h"

//global parameters shared by different programs
extern int	m;//#CNs
extern int	n;//#VNs
extern int	l;//int-width of CN value
extern VVI	CN_adj;//neighbors of CNs
extern VVI	CN_val;//XOR value of CNs

//global parameters generated and shared by BP
extern int	maxIter;

//BP in the likelihood domain P(x=0)/P(x=1): true/false <-> correct/incorrect
//p: correct probability of each received symbol
//info: source symbles
bool BP(const double &p, const VVI &info);

	
#endif
