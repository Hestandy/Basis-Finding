#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <algorithm>
#include <map>
#include <vector>
#include <queue>
#include <cmath>
#include <set>
#include <list>
#include <ctime>
#include <cassert>
#include <sstream>
#include <random>
#define MP make_pair
#define PB push_back

using namespace std;

typedef long long LL;
typedef vector <LL> VLL;
typedef vector <bool> VB;
typedef vector <VB> VVB;
typedef vector <int> VI;
typedef vector <VI> VVI;
typedef vector <double> VD;
typedef vector <VD> VVD;
typedef pair <int, int> PII;
typedef vector <PII> VPII;
typedef vector <string> VS;

const double eps = 1e-9;
const double INF = 1e9;
const double PI = 3.141592653589793;
const double e = 2.71828182845904523536;
const int MAXN = 205;
const int MAXL = 105;
const int MAXM = 405;

double p2[MAXM];//2^i
double _p2[MAXM];//_p2[0] = 1; _p2[i] = _p2[i-1] * (1 - 2^-i)
double C[MAXM][MAXM];//#combinations


double p0;
int n;
int l;
int m;

//a x b random matrix is of rank b;
//whether each column can be zero
double a_rank_b(int a, int b, bool allow_zero){
	assert(a >= b && a < MAXM && b >= 0);
	
	if (allow_zero){
		return	_p2[a] / _p2[a - b];
	}
	else{
		return	_p2[a] / _p2[a - b] * p2[a] / (p2[a] - 1);
	}
}

VD calc_PE(){
	assert(n < MAXN && l < MAXL && m < MAXM);
	
	//#received symbols; 
	//#correct basis elements
	//#incorrect basis elements and their syndromes are linearly independent
	vector <VVD> PE(2, VVD(n + 1, VD(l + 1, 0.0)));
	PE[0][0][0] = 1;
	VD res(m + 1, 0.0);
	bool id = false;
	for (int a = 1; a <= m; ++ a){
		id = !id;
		for (int b = min(a, n); b >= 0; -- b){
			for (int c = min(l, a - b); c >= 0; -- c){
				PE[id][b][c]  = PE[!id][b][c] * p0 * p2[b] / p2[n];
				PE[id][b][c] += PE[!id][b][c] * (1 - p0) * (p2[b + c] - p2[b]) / (p2[n + l] - p2[n]);
				if (b > 0){
					PE[id][b][c] += PE[!id][b - 1][c] * p0 * (p2[n] - p2[b - 1]) / p2[n];
				}
				if (c > 0){
					PE[id][b][c] += PE[!id][b][c - 1] * (1 - p0) * (p2[n + l] - p2[n + c - 1]) / (p2[n + l] - p2[n]);
				}
				
				if (b == n){
					res[a] += PE[id][b][c];
				}
			}
		}
	}
	return	res;
}

VD calc_PE_approx(){
	assert(n < MAXN && l < MAXL && m < MAXM);
	
	VD	res(m + 1, 0);
	for (int j = n; j <= m; ++ j){
		for (int i = max(n, j-l); i <= j; ++ i){
			res[j] += C[j][i] * pow(p0, i) * pow(1-p0, j-i) * a_rank_b(i, n, 1) * a_rank_b(l, j-i, 0);
			//the following is to approximate rank property, differ very little
//			res[j] += C[j][i] * pow(p0, i) * pow(1-p0, j-i) * (1 - pow(2.0, n-i)) * (1 - pow(2.0, j-i-l));
		}
	}
	return	res;
}


VD calc_PG(){
	assert(n < MAXN && l < MAXL && m < MAXM);
	
	//#correct symbols
	//their rank
	//#basis elements attending 0 linear combinations
	vector <VVD> PG(2, VVD(n + 1, VD(n + 1, 0.0)));
	PG[0][0][0] = 1;
	VD PGn0(m + 1, 0);//PG[][n][0]
	bool id = false;
	for (int a = 1; a <= m; ++ a){
		id = !id;
		for (int b = min(a, n); b >= 0; -- b){
			for (int c = 0; c <= b; ++ c){
				PG[id][b][c] = 0;
				for (int t = c; t <= b; ++ t){
					PG[id][b][c] += PG[!id][b][t] * C[t][c] * p2[b - t] / p2[n];
				}
				if (b > 0 && c > 0){
					PG[id][b][c] += PG[!id][b - 1][c - 1] * (p2[n] - p2[b - 1]) / p2[n];
				}
			}
		}
		PGn0[a] = PG[id][n][0];
	}
	
	VD	res(m + 1, 0);
	for (int j = n; j <= m; ++ j){
		for (int i = max(n, j-l); i <= j; ++ i){
			res[j] += C[j][i] * pow(p0, i) * pow(1-p0, j-i) * PGn0[i] *  a_rank_b(l, j-i, 0);
			//the following is to approximate rank property, differ very little
//			res[j] += C[j][i] * pow(p0, i) * pow(1-p0, j-i) * PGn0[i] * (1 - pow(2.0, j-i-l));
		}
	}
	return	res;
}

VD calc_PG_approx(){
	assert(n < MAXN && l < MAXL && m < MAXM);
	
	VD	res(m + 1, 0);
	for (int j = n; j <= m; ++ j){
		for (int i = max(n, j-l); i <= j; ++ i){
			int u = i - n;
			int v = log2(sqrt((n-1.0)*(n-1) + n*p2[u+2]) - n + 1) - 1;
			double w = a_rank_b(i-v, n, 1) * pow(1 - pow(2.0, -v), n);
			if (v < u){
				w = max(w, a_rank_b(i-v-1, n, 1) * pow(1 - pow(2.0, -v-1), n));
			}
			res[j] += C[j][i] * pow(p0, i) * pow(1-p0, j-i) * w * a_rank_b(l, j-i, 0);
		}
	}
	return	res;
}

int main()
{
	p2[0] = _p2[0] = 1;
	for (int i = 1; i < MAXM; ++ i){
		p2[i]  = p2[i - 1] * 2;
		_p2[i] = _p2[i - 1] * (1 - 1/p2[i]);
	}
	
	C[0][0] = 1;
	for (int i = 1; i < MAXM; ++ i){
		C[i][0] = C[i][i] = 1;
		for (int j = 1; j < i; ++ j){
			C[i][j] = C[i - 1][j - 1] + C[i - 1][j];
		}
	}
	
	cerr << C[400][200] << " " << p2[400] << endl;
	
	n = 200;
	l = 100;
	m = 400;
	
	char fileName[100];
	sprintf(fileName, "calcPG,n=%d,l=%d,m=%d.txt", n, l, m);
	freopen(fileName, "w", stdout);
	
	double _p0[] = {0.7, 0.73, 0.76, 0.79};
	for (int i = 0; i <= 3; ++ i){
		p0 = _p0[i];
		
		VD res = calc_PE();
//		VD res = calc_PE_approx();
		
//		VD res = calc_PG();
//		VD res = calc_PG_approx();
		
//		
		printf("p0 = %.2f, m = [%d, %d]\n", p0, n, m);
		for (int j = n; j <= m; ++ j){
			printf("%e ", 1 - res[j]);
		}
		printf("\n\n");
	}
	

	return 0;
}


