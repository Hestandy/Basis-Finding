#include "BP4LT.h"

int	maxIter;//maximum iterations for BP
VD	vnMsg;//varable nodes' messages: P(x=0) / P(x=1)
VB	vnBit;//a bit of info
VD	msgVC;//messages pass from varible nodes to check nodes: P(x=0) - P(x=1)
VD	cnMsg;//check nodes' messages: P(x=0) - P(x=1)
VB	cnBit;//a bit of CN_val
VVD	msgCV;//messages pass from check nodes to varible nodes: P(x=0) / P(x=1)

//P(x=0) / P(x=1) -> P(x=0) - P(x=1)
double divisionToSubtraction (const double &x){
	if (sgn (x - 1) != 0)	return	(x - 1) / (x + 1);
	else 					return	x > 1 ? eps : -1 * eps;			
}

//P(x=0) - P(x=1) -> P(x=0) / P(x=1)
double subtractionToDivision (const double &x){
	if (sgn (1 - x) == 0)		return	INF;
	else if (sgn (1 + x) == 0)	return	eps;
	else						return	(1 + x) / (1 - x);	
}

bool be_codeword(const VB &cw){
	for (int i = 0; i < CN_adj.size(); ++ i){
		bool sum = cnBit[i];
		for (int j = 0; j < CN_adj[i].size(); ++ j){
			sum ^= cw[CN_adj[i][j]];
		}
		if (sum){
			return	false;
		}
	}
	return	true;
}

VB BP_for_1bit (){
	VB	res(n);
	for (int it = 0; it < maxIter; ++ it){
		VD preVarMsg = vnMsg;
		for (int r = 0; r < CN_adj.size(); ++ r){
			double all = cnMsg[r];
			for (int j = 0; j < CN_adj[r].size(); ++ j){
				int c = CN_adj[r][j];
				msgVC[c] = divisionToSubtraction (preVarMsg[c] / msgCV[r][j]);
				all *= msgVC[c];
			}	
			for(int j = 0; j < CN_adj[r].size(); ++ j){
				int c = CN_adj[r][j];
				if (vnMsg[c] > eps2 && vnMsg[c] < INF2){//to avoid double overflow
					vnMsg[c] /= msgCV[r][j];
					msgCV[r][j] = subtractionToDivision (all / msgVC[c]);
					vnMsg[c] *= msgCV[r][j];
				}
			}
		}
		
		for (int j = 0; j < vnMsg.size(); ++ j){
			res[j] = vnMsg[j] < 1.0;
		}
		if (be_codeword(res)){
			return	res;//comments for non-stopping decoding
		}
	}
	return	res;
}

bool BP (const double &p, const VVI &info){
	vnMsg.resize(n);
	vnBit.resize(n);
	msgVC.resize(n);
	cnMsg.resize(m);
	cnBit.resize(m);
	msgCV.resize(m);
	for (int i = 0; i < CN_adj.size(); ++ i){
		msgCV[i].resize(CN_adj[i].size());
	}
	
	//for the b-th bit 
	for (int b = 0; b < l; ++ b){
		for (int j = 0; j < n; ++ j){
			vnMsg[j] = 1;
			vnBit[j] = (info[j][b/BWI] >> b%BWI) & 1;
		}
		for (int i = 0; i < msgCV.size(); ++ i){
			cnBit[i] = (CN_val[i][b/BWI] >> b%BWI) & 1;
			cnMsg[i] = (p - (1 - p) / (pow(2, l) - 1)) * (1 - 2*cnBit[i]);
			for (int j = 0; j < msgCV[i].size(); ++ j){
				msgCV[i][j] = 1.0;	
			}
		}
		
		if (BP_for_1bit() != vnBit){
			return	false;
		}
	}
	return	true;
}


